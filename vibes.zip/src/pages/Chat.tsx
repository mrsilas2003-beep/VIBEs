import { useState, useRef, useEffect } from 'react';
import { useStore } from '../store';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Send, EyeOff, Eye, Sparkles, Camera, Mic, Image as ImageIcon, 
  PlusCircle, Smile, MoreHorizontal, ChevronLeft, Info
} from 'lucide-react';
import { format } from 'date-fns';

const VIBE_EMOJIS = ['😍', '🤩', '🔥', '✨', '🙌', '💯', '🥂', '🎓', '📚', '💃', '🕺', '💜'];

export default function Chat() {
  const { currentUser, users, sendMessage, messages, markMessageViewed } = useStore();
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [messageText, setMessageText] = useState('');
  const [isViewOnce, setIsViewOnce] = useState(false);
  const [showEmojis, setShowEmojis] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  const selectedUser = users.find(u => u.id === selectedUserId);
  const chatMessages = messages.filter(m => 
    (m.senderId === currentUser?.id && m.receiverId === selectedUserId) ||
    (m.senderId === selectedUserId && m.receiverId === currentUser?.id)
  ).sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [chatMessages, selectedUserId]);

  const handleSendMessage = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (messageText.trim() && selectedUserId) {
      sendMessage(selectedUserId, messageText, isViewOnce);
      setMessageText('');
      setIsViewOnce(false);
      setShowEmojis(false);
    }
  };

  const handleEmojiClick = (emoji: string) => {
    setMessageText(prev => prev + emoji);
  };

  return (
    <div className="h-[calc(100vh-140px)] flex justify-center items-center">
      {/* Container holding both contact list and the "Phone" */}
      <div className="w-full max-w-6xl h-full flex gap-8 items-start">
        
        {/* Contact List (Desktop) */}
        <div className="hidden lg:flex w-80 h-full glass rounded-[2.5rem] flex-col overflow-hidden">
          <div className="p-8 pb-4">
            <h2 className="text-3xl font-display font-bold text-white mb-2">Messages</h2>
            <div className="relative">
              <input 
                type="text" 
                placeholder="Search" 
                className="w-full bg-white/5 border-none rounded-xl px-4 py-2 text-sm focus:ring-0 focus:bg-white/10 transition-colors"
              />
            </div>
          </div>
          <div className="flex-1 overflow-y-auto px-4 pb-4 space-y-1">
            {users
              .filter(u => u.id !== currentUser?.id)
              .map(user => (
                <button
                  key={user.id}
                  onClick={() => setSelectedUserId(user.id)}
                  className={`w-full flex items-center gap-4 p-4 rounded-3xl transition-all ${
                    selectedUserId === user.id ? 'bg-white/10 ring-1 ring-white/10 shadow-xl' : 'hover:bg-white/5'
                  }`}
                >
                  <div className="relative">
                    <img src={user.avatar} alt="Avatar" className="w-12 h-12 rounded-full border border-white/10" />
                    <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-black" />
                  </div>
                  <div className="text-left flex-1 min-w-0">
                    <div className="flex justify-between items-center">
                      <p className="font-bold text-sm truncate">{user.username}</p>
                      <span className="text-[10px] text-gray-500">now</span>
                    </div>
                    <p className="text-xs text-gray-400 truncate">Vibing at {user.university}</p>
                  </div>
                </button>
              ))}
          </div>
        </div>

        {/* iPhone 17 Pro Max Frame Simulator */}
        <div className="flex-1 lg:flex-none lg:w-[410px] h-full flex flex-col mx-auto relative group">
          {/* Main Chat Area */}
          <div className="flex-1 glass-dark rounded-[3.5rem] border-[8px] border-zinc-800 shadow-2xl relative overflow-hidden flex flex-col bg-black">
            
            {/* Dynamic Island Inspired Header */}
            {selectedUser ? (
              <div className="pt-10 pb-4 px-6 flex flex-col items-center glass border-b border-white/5 relative z-20">
                <div className="flex items-center justify-between w-full mb-4">
                  <button 
                    onClick={() => setSelectedUserId(null)}
                    className="p-1 text-ios-blue hover:opacity-70 lg:hidden"
                  >
                    <ChevronLeft size={24} />
                  </button>
                  <div className="flex flex-col items-center">
                    <img 
                      src={selectedUser.avatar} 
                      alt="Avatar" 
                      className="w-12 h-12 rounded-full ring-2 ring-white/10 mb-2 shadow-2xl" 
                    />
                    <div className="flex items-center gap-1">
                      <h3 className="font-bold text-sm">{selectedUser.username}</h3>
                      <ChevronLeft className="-rotate-90 text-gray-500" size={12} />
                    </div>
                  </div>
                  <button className="p-1 text-ios-blue hover:opacity-70">
                    <Info size={20} />
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center p-12 text-center">
                 <div className="w-20 h-20 rounded-[2rem] glass flex items-center justify-center mb-6 animate-float">
                    <Smile size={40} className="text-ios-blue" />
                 </div>
                 <h2 className="text-2xl font-display font-bold mb-2">Your Conversations</h2>
                 <p className="text-gray-500 text-sm">Select a contact to start vibing on iMessage</p>
              </div>
            )}

            {/* Messages Area */}
            <div 
              ref={scrollRef}
              className="flex-1 overflow-y-auto px-4 py-6 space-y-4 scroll-smooth"
              style={{ backgroundImage: 'radial-gradient(circle at 50% 50%, rgba(255,255,255,0.02) 0%, transparent 100%)' }}
            >
              {selectedUserId ? (
                chatMessages.length > 0 ? (
                  chatMessages.map((msg, idx) => {
                    const isMine = msg.senderId === currentUser?.id;
                    const isNextMine = chatMessages[idx + 1]?.senderId === currentUser?.id;
                    const isPrevMine = chatMessages[idx - 1]?.senderId === currentUser?.id;

                    const showAvatar = !isMine && chatMessages[idx + 1]?.senderId !== msg.senderId;

                    return (
                      <motion.div
                        key={msg.id}
                        initial={{ opacity: 0, scale: 0.95, y: 10 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        className={`flex items-end gap-2 ${isMine ? 'justify-end' : 'justify-start'} ${!isNextMine && isMine ? 'mb-4' : 'mb-0.5'}`}
                      >
                        {!isMine && (
                          <div className="w-6 h-6 flex-shrink-0">
                            {showAvatar && (
                              <img src={selectedUser?.avatar} className="w-6 h-6 rounded-full" alt="" />
                            )}
                          </div>
                        )}
                        <div className={`
                          relative group/msg
                          ${isMine ? 'imessage-me' : 'imessage-them'}
                          ${!isPrevMine && isMine ? 'rounded-tr-[22px]' : ''}
                        `}>
                          {msg.viewOnce ? (
                            !msg.viewed && !isMine ? (
                              <button 
                                onClick={() => markMessageViewed(msg.id)}
                                className="flex items-center gap-2 py-1 px-3 bg-white/20 rounded-full text-xs font-bold"
                              >
                                <Eye size={14} />
                                Tap to View
                              </button>
                            ) : (
                              <div className="text-sm italic opacity-50 flex items-center gap-1 py-1">
                                <EyeOff size={14} />
                                Disappeared
                              </div>
                            )
                          ) : (
                            <p className="text-[15px] leading-tight select-all">{msg.content}</p>
                          )}
                        </div>
                      </motion.div>
                    );
                  })
                ) : (
                  <div className="h-full flex flex-col items-center justify-center opacity-30">
                    <p className="text-sm font-medium">iMessage</p>
                    <p className="text-[10px] mt-1">End-to-End Encrypted</p>
                  </div>
                )
              ) : null}
            </div>

            {/* iOS Footer Input */}
            {selectedUserId && (
              <div className="p-4 bg-black/80 backdrop-blur-3xl pb-8">
                <AnimatePresence>
                  {showEmojis && (
                    <motion.div 
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 10 }}
                      className="glass-dark rounded-3xl p-3 mb-4 grid grid-cols-6 gap-2"
                    >
                      {VIBE_EMOJIS.map(e => (
                        <button 
                          key={e} 
                          onClick={() => handleEmojiClick(e)}
                          className="text-2xl hover:bg-white/10 p-2 rounded-xl transition-colors"
                        >
                          {e}
                        </button>
                      ))}
                    </motion.div>
                  )}
                </AnimatePresence>

                <div className="flex items-center gap-3">
                  <button className="text-gray-400 hover:text-white transition-colors">
                    <PlusCircle size={24} />
                  </button>
                  <button className="text-gray-400 hover:text-white transition-colors">
                    <Camera size={24} />
                  </button>
                  <button className="text-gray-400 hover:text-white transition-colors">
                    <ImageIcon size={24} />
                  </button>
                  
                  <div className="flex-1 relative">
                    <input 
                      type="text"
                      value={messageText}
                      onChange={(e) => setMessageText(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                      placeholder="iMessage"
                      className={`
                        w-full bg-[#1C1C1E] border border-[#3A3A3C] rounded-3xl px-4 py-2 text-[15px] focus:outline-none focus:border-ios-blue transition-all
                        ${isViewOnce ? 'border-vibe-pink text-vibe-pink' : ''}
                      `}
                    />
                    <div className="absolute right-1 top-1/2 -translate-y-1/2 flex items-center gap-1">
                       <button 
                        onClick={() => setIsViewOnce(!isViewOnce)}
                        className={`p-1.5 rounded-full transition-colors ${isViewOnce ? 'text-vibe-pink' : 'text-gray-500'}`}
                      >
                        <Eye size={16} />
                      </button>
                      <button 
                        onClick={() => setShowEmojis(!showEmojis)}
                        className={`p-1.5 rounded-full transition-colors ${showEmojis ? 'text-ios-blue' : 'text-gray-500'}`}
                      >
                        <Smile size={18} />
                      </button>
                    </div>
                  </div>

                  <button 
                    disabled={!messageText.trim()}
                    onClick={() => handleSendMessage()}
                    className={`
                      p-2 rounded-full transition-all
                      ${messageText.trim() ? 'bg-ios-blue text-white shadow-lg shadow-ios-blue/30 scale-100' : 'bg-gray-800 text-gray-500 scale-90'}
                    `}
                  >
                    <Send size={18} />
                  </button>
                </div>
              </div>
            )}

            {/* Bottom Notch / Bar */}
            <div className="h-1.5 w-32 bg-zinc-800 rounded-full mx-auto my-3" />
          </div>

          {/* Device Gloss/Reflections */}
          <div className="absolute inset-0 pointer-events-none rounded-[3.5rem] border-[2px] border-white/5 opacity-50 z-30" />
        </div>

        {/* Info Right Panel (Desktop) */}
        {selectedUser && (
          <div className="hidden xl:flex w-64 glass rounded-[2.5rem] flex-col overflow-hidden p-8">
            <div className="flex flex-col items-center text-center">
              <img src={selectedUser.avatar} alt="" className="w-24 h-24 rounded-full border-4 border-white/5 mb-4 shadow-xl shadow-black" />
              <h3 className="text-xl font-bold">{selectedUser.username}</h3>
              <p className="text-xs text-gray-500 mt-1 uppercase tracking-widest">{selectedUser.university}</p>
            </div>
            
            <div className="mt-12 space-y-6">
              <div>
                <h4 className="text-[10px] font-bold text-gray-500 uppercase tracking-[0.2em] mb-3">Links & Photos</h4>
                <div className="grid grid-cols-2 gap-2">
                  <div className="aspect-square bg-white/5 rounded-xl border border-white/5" />
                  <div className="aspect-square bg-white/5 rounded-xl border border-white/5" />
                </div>
              </div>
              
              <button className="w-full py-3 rounded-2xl bg-white/5 text-xs font-semibold hover:bg-white/10 transition-colors border border-white/5">
                View Profile
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
