import { useState } from 'react';
import { motion } from 'motion/react';
import { useStore } from '../store';
import { Mail, User, GraduationCap, ArrowRight, Lock } from 'lucide-react';

export default function Auth() {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [university, setUniversity] = useState('');
  const { login, signup } = useStore();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isLogin) {
      login(email);
    } else {
      signup(username, email, university);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="glass-dark p-8 rounded-3xl"
        >
          <div className="text-center mb-8">
            <h2 className="text-3xl font-display font-bold mb-2">
              {isLogin ? 'Welcome Back' : 'Join VIBEs'}
            </h2>
            <p className="text-gray-400 text-sm">
              {isLogin 
                ? 'Enter your student email to continue' 
                : 'Create your academic identity'}
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <div className="space-y-1">
                <label className="text-xs font-semibold uppercase tracking-wider text-gray-500 ml-2">Username</label>
                <div className="relative">
                  <User size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" />
                  <input
                    type="text"
                    required
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="input-vibe pl-12"
                    placeholder="student_star"
                  />
                </div>
              </div>
            )}

            <div className="space-y-1">
              <label className="text-xs font-semibold uppercase tracking-wider text-gray-500 ml-2">University Email</label>
              <div className="relative">
                <Mail size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="input-vibe pl-12"
                  placeholder="name@uni.edu"
                />
              </div>
            </div>

            {!isLogin && (
              <div className="space-y-1">
                <label className="text-xs font-semibold uppercase tracking-wider text-gray-500 ml-2">University</label>
                <div className="relative">
                  <GraduationCap size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" />
                  <input
                    type="text"
                    required
                    value={university}
                    onChange={(e) => setUniversity(e.target.value)}
                    className="input-vibe pl-12"
                    placeholder="Oxford University"
                  />
                </div>
              </div>
            )}

            {isLogin && (
              <p className="text-[10px] text-gray-500 text-center py-2 italic">
                * For this demo, try alex@uni.edu, sam@uni.edu, or jordan@uni.edu
              </p>
            )}

            <button type="submit" className="w-full btn-vibe-primary flex items-center justify-center gap-2 mt-6">
              {isLogin ? 'Sign In' : 'Create Account'}
              <ArrowRight size={20} />
            </button>
          </form>

          <div className="mt-8 pt-6 border-t border-white/5 text-center">
            <button
              onClick={() => setIsLogin(!isLogin)}
              className="text-sm text-gray-400 hover:text-white transition-colors"
            >
              {isLogin ? "Don't have an account? Sign Up" : "Already have an account? Sign In"}
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
