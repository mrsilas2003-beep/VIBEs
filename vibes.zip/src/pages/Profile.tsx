import { useParams, Link } from 'react-router-dom';
import { useStore } from '../store';
import { motion } from 'motion/react';
import { GraduationCap, MapPin, Calendar, Heart, MessageSquare, Edit3, UserPlus, Check } from 'lucide-react';
import { format } from 'date-fns';

export default function Profile() {
  const { userId } = useParams<{ userId: string }>();
  const { users, currentUser, posts, sendFriendRequest } = useStore();
  
  const user = users.find(u => u.id === userId);
  const userPosts = posts.filter(p => p.authorId === userId);
  const isOwnProfile = currentUser?.id === userId;
  const isFriend = currentUser?.friends.includes(userId || '');
  const hasSentRequest = user?.friendRequests.includes(currentUser?.id || '');

  if (!user) {
    return (
      <div className="text-center py-20">
        <h2 className="text-2xl font-bold">User Not Found</h2>
        <Link to="/" className="text-vibe-purple mt-4 inline-block">Go back home</Link>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      {/* Header Info */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass rounded-[3rem] overflow-hidden"
      >
        <div className="h-48 bg-gradient-to-r from-vibe-purple/20 via-vibe-pink/20 to-vibe-cyan/20" />
        <div className="px-8 pb-12 -mt-16">
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6">
            <div className="flex flex-col md:flex-row md:items-end gap-6">
              <img 
                src={user.avatar} 
                alt={user.username} 
                className="w-32 h-32 rounded-[2rem] border-4 border-black ring-4 ring-white/5 shadow-2xl bg-black" 
              />
              <div className="mb-4">
                <h1 className="text-4xl font-display font-bold">{user.username}</h1>
                <div className="flex flex-wrap items-center gap-4 text-sm text-gray-400 mt-2">
                  <span className="flex items-center gap-1">
                    <GraduationCap size={16} className="text-vibe-purple" />
                    {user.university}
                  </span>
                  {user.friends.length > 0 && (
                    <span className="flex items-center gap-1">
                      <Heart size={16} className="text-vibe-pink" />
                      {user.friends.length} Network Connections
                    </span>
                  )}
                </div>
              </div>
            </div>
            
            <div className="mb-4">
              {isOwnProfile ? (
                <button className="btn-vibe-secondary flex items-center gap-2">
                  <Edit3 size={18} />
                  Edit Profile
                </button>
              ) : isFriend ? (
                <div className="flex gap-2">
                  <button disabled className="btn-vibe-secondary flex items-center gap-2 opacity-100">
                    <Check size={18} className="text-vibe-cyan" />
                    Friends
                  </button>
                  <Link to="/chat" className="btn-vibe-primary px-6">Message</Link>
                </div>
              ) : hasSentRequest ? (
                <button disabled className="btn-vibe-secondary opacity-50">Request Sent</button>
              ) : (
                <button 
                  onClick={() => sendFriendRequest(user.id)}
                  className="btn-vibe-primary flex items-center gap-2"
                >
                  <UserPlus size={18} />
                  Connect
                </button>
              )}
            </div>
          </div>

          <div className="mt-8 pt-8 border-t border-white/5 max-w-2xl">
            <h3 className="text-xs font-bold uppercase tracking-widest text-gray-500 mb-4">Biography</h3>
            <p className="text-lg text-gray-300 leading-relaxed italic">
              "{user.bio || 'This student prefers to keep a mysterious aura. No bio yet!'}"
            </p>
          </div>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Sidebar - Details */}
        <div className="space-y-6">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="glass p-6 rounded-3xl"
          >
            <h3 className="font-bold mb-4">Interests</h3>
            <div className="flex flex-wrap gap-2">
              {['Coding', 'UI Design', 'University Life', 'Late Night Studies', 'Coffee'].map(tag => (
                <span key={tag} className="px-3 py-1 rounded-full bg-white/5 text-xs text-gray-400 border border-white/5">
                  #{tag}
                </span>
              ))}
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
            className="glass p-6 rounded-3xl"
          >
            <h3 className="font-bold mb-4">Recent Activity</h3>
            <div className="space-y-4">
              <div className="flex gap-3 text-xs">
                <div className="w-1 bg-vibe-purple rounded-full" />
                <div>
                  <p className="text-gray-300">Joined VIBEs Community</p>
                  <p className="text-gray-500 mt-1">October 2023</p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* User Posts */}
        <div className="lg:col-span-2 space-y-6">
          <h2 className="text-2xl font-display font-bold">Discussions</h2>
          {userPosts.map((post, idx) => (
            <motion.div
              key={post.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="glass p-6 rounded-3xl"
            >
              <div className="flex items-center gap-2 mb-4">
                <span className="text-[10px] uppercase font-bold text-vibe-purple tracking-widest bg-vibe-purple/10 px-3 py-1 rounded-full">
                  {post.category}
                </span>
                <span className="text-xs text-gray-500">
                  {format(new Date(post.timestamp), 'MMM dd, yyyy')}
                </span>
              </div>
              <h3 className="text-xl font-bold mb-2">{post.title}</h3>
              <p className="text-gray-400 text-sm mb-6 line-clamp-3">{post.content}</p>
              <div className="flex items-center gap-6">
                 <span className="flex items-center gap-2 text-xs text-gray-500">
                  <Heart size={14} />
                  {post.likes.length}
                </span>
                <span className="flex items-center gap-2 text-xs text-gray-500">
                  <MessageSquare size={14} />
                  {post.comments.length}
                </span>
              </div>
            </motion.div>
          ))}
          {userPosts.length === 0 && (
            <div className="glass p-12 rounded-3xl text-center text-gray-500">
              This student hasn't started any discussions yet.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
