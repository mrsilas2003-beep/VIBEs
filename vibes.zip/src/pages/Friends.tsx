import { useStore } from '../store';
import { motion } from 'motion/react';
import { UserPlus, Check, X, UserMinus, Search } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Friends() {
  const { users, currentUser, sendFriendRequest, acceptFriendRequest, markNotificationRead } = useStore();

  const handleSendRequest = (userId: string) => {
    sendFriendRequest(userId);
  };

  const currentFriends = users.filter(u => currentUser?.friends.includes(u.id));
  const suggestedUsers = users.filter(u => 
    u.id !== currentUser?.id && 
    !currentUser?.friends.includes(u.id) && 
    !u.friendRequests.includes(currentUser?.id || '')
  );
  const receivedRequests = users.filter(u => currentUser?.friendRequests.includes(u.id));

  return (
    <div className="space-y-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-4xl font-display font-bold">Connections</h1>
          <p className="text-gray-400 mt-2">Manage your academic network and discover new people.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Main Content */}
        <div className="lg:col-span-8 space-y-12">
          {receivedRequests.length > 0 && (
            <section>
              <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
                <span className="w-8 h-8 rounded-lg bg-vibe-pink/20 text-vibe-pink flex items-center justify-center">
                  {receivedRequests.length}
                </span>
                Pending Requests
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {receivedRequests.map(user => (
                  <motion.div
                    key={user.id}
                    layout
                    className="glass p-4 rounded-2xl flex items-center justify-between"
                  >
                    <Link to={`/profile/${user.id}`} className="flex items-center gap-3">
                      <img src={user.avatar} alt="Avatar" className="w-12 h-12 rounded-full" />
                      <div>
                        <p className="font-bold">{user.username}</p>
                        <p className="text-[10px] text-gray-500 uppercase tracking-widest">{user.university}</p>
                      </div>
                    </Link>
                    <div className="flex gap-2">
                      <button 
                        onClick={() => acceptFriendRequest(user.id)}
                        className="p-2 bg-vibe-purple rounded-xl hover:bg-vibe-purple/80 transition-colors"
                      >
                        <Check size={18} />
                      </button>
                      <button className="p-2 bg-white/5 rounded-xl hover:bg-white/10 transition-colors">
                        <X size={18} />
                      </button>
                    </div>
                  </motion.div>
                ))}
              </div>
            </section>
          )}

          <section>
            <h2 className="text-xl font-bold mb-6">Your Network</h2>
            {currentFriends.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {currentFriends.map(user => (
                  <Link
                    key={user.id}
                    to={`/profile/${user.id}`}
                    className="glass p-4 rounded-2xl flex items-center justify-between hover:bg-white/5 transition-colors group"
                  >
                    <div className="flex items-center gap-3">
                      <img src={user.avatar} alt="Avatar" className="w-12 h-12 rounded-full" />
                      <div>
                        <p className="font-bold group-hover:text-vibe-purple transition-colors">{user.username}</p>
                        <p className="text-[10px] text-gray-500 uppercase">{user.university}</p>
                      </div>
                    </div>
                    <Link 
                      to="/chat"
                      className="p-2 text-gray-500 hover:text-white"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <MessageSquare size={18} />
                    </Link>
                  </Link>
                ))}
              </div>
            ) : (
              <div className="glass p-12 rounded-3xl text-center space-y-4">
                <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mx-auto">
                  <UserPlus size={32} className="text-gray-500" />
                </div>
                <p className="text-gray-400">You haven't added any friends yet.</p>
              </div>
            )}
          </section>
        </div>

        {/* Sidebar - Discover */}
        <div className="lg:col-span-4 space-y-6">
          <div className="glass p-6 rounded-3xl">
            <h3 className="font-bold mb-6 flex items-center gap-2">
              <Search size={18} className="text-vibe-cyan" />
              Discover Students
            </h3>
            <div className="space-y-4">
              {suggestedUsers.map(user => (
                <div key={user.id} className="flex items-center justify-between group">
                  <Link to={`/profile/${user.id}`} className="flex items-center gap-3">
                    <img src={user.avatar} alt="Avatar" className="w-8 h-8 rounded-full" />
                    <div>
                      <p className="text-xs font-bold group-hover:text-vibe-purple transition-colors">{user.username}</p>
                      <p className="text-[10px] text-gray-500">{user.university}</p>
                    </div>
                  </Link>
                  <button 
                    onClick={() => handleSendRequest(user.id)}
                    className="p-2 text-gray-500 hover:text-vibe-purple transition-colors"
                  >
                    <UserPlus size={16} />
                  </button>
                </div>
              ))}
              {suggestedUsers.length === 0 && (
                <p className="text-[10px] text-gray-500 text-center">No more suggestions for now</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

const MessageSquare = ({ size, className }: { size?: number, className?: string }) => (
  <svg 
    width={size} 
    height={size} 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    className={className}
  >
    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
  </svg>
)
