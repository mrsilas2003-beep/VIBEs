import { useState } from 'react';
import { useStore } from '../store';
import { motion, AnimatePresence } from 'motion/react';
import { MessageSquare, Plus, Send, X, MessageCircle, Heart, User } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { ForumPost } from '../types';

export default function Forum() {
  const { posts, createPost, likePost, addComment, users, currentUser } = useStore();
  const [showCreate, setShowCreate] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newContent, setNewContent] = useState('');
  const [newCategory, setNewCategory] = useState<ForumPost['category']>('General');
  const [commentText, setCommentText] = useState<{ [key: string]: string }>({});

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    createPost(newTitle, newContent, newCategory);
    setNewTitle('');
    setNewContent('');
    setShowCreate(false);
  };

  const handleComment = (postId: string) => {
    const text = commentText[postId];
    if (text?.trim()) {
      addComment(postId, text);
      setCommentText({ ...commentText, [postId]: '' });
    }
  };

  const getAuthor = (id: string) => users.find(u => u.id === id);

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-display font-bold">Community Forum</h1>
          <p className="text-gray-400 mt-2">Join the conversation. Text-only vibes.</p>
        </div>
        <button 
          onClick={() => setShowCreate(true)}
          className="btn-vibe-primary flex items-center gap-2"
        >
          <Plus size={20} />
          <span>New Topic</span>
        </button>
      </div>

      <AnimatePresence>
        {showCreate && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="glass-dark p-6 rounded-3xl"
          >
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-bold">Start a Discussion</h3>
              <button onClick={() => setShowCreate(false)} className="text-gray-500 hover:text-white">
                <X size={20} />
              </button>
            </div>
            <form onSubmit={handleCreate} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="md:col-span-3">
                  <input
                    type="text"
                    required
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    placeholder="Topic Title"
                    className="input-vibe"
                  />
                </div>
                <select 
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value as any)}
                  className="input-vibe bg-black"
                >
                  <option value="General">General</option>
                  <option value="Dating">Dating</option>
                  <option value="Events">Events</option>
                  <option value="Study">Study</option>
                </select>
              </div>
              <textarea
                required
                value={newContent}
                onChange={(e) => setNewContent(e.target.value)}
                placeholder="What's on your mind? Just text, please."
                rows={4}
                className="input-vibe resize-none"
              />
              <div className="flex justify-end">
                <button type="submit" className="btn-vibe-primary px-8">Post Discussion</button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="space-y-6">
        {posts.map((post) => {
          const author = getAuthor(post.authorId);
          return (
            <motion.div
              key={post.id}
              layout
              className="glass p-6 rounded-3xl"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <img src={author?.avatar} alt={author?.username} className="w-10 h-10 rounded-full" />
                  <div>
                    <h3 className="font-bold">{post.title}</h3>
                    <p className="text-xs text-gray-400">
                      by {author?.username} • {formatDistanceToNow(new Date(post.timestamp))} ago
                    </p>
                  </div>
                </div>
                <span className="text-[10px] font-bold uppercase tracking-widest text-vibe-cyan bg-vibe-cyan/10 px-3 py-1 rounded-full">
                  {post.category}
                </span>
              </div>
              
              <p className="text-gray-300 mb-6 leading-relaxed whitespace-pre-wrap">
                {post.content}
              </p>

              <div className="flex items-center gap-6 mb-6">
                <button 
                  onClick={() => likePost(post.id)}
                  className={`flex items-center gap-2 text-sm transition-colors ${post.likes.includes(currentUser?.id || '') ? 'text-vibe-pink' : 'text-gray-500 hover:text-white'}`}
                >
                  <Heart size={18} fill={post.likes.includes(currentUser?.id || '') ? 'currentColor' : 'none'} />
                  {post.likes.length} Likes
                </button>
                <div className="flex items-center gap-2 text-sm text-gray-500">
                  <MessageSquare size={18} />
                  {post.comments.length} Comments
                </div>
              </div>

              {/* Comments Section */}
              <div className="space-y-4 pt-6 border-t border-white/5">
                {post.comments.map((comment) => {
                  const cAuthor = getAuthor(comment.authorId);
                  return (
                    <div key={comment.id} className="flex gap-3">
                      <img src={cAuthor?.avatar} alt={cAuthor?.username} className="w-8 h-8 rounded-full" />
                      <div className="flex-1 bg-white/5 p-3 rounded-2xl rounded-tl-none">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-xs font-bold">{cAuthor?.username}</span>
                          <span className="text-[10px] text-gray-500">{formatDistanceToNow(new Date(comment.timestamp))} ago</span>
                        </div>
                        <p className="text-sm text-gray-300">{comment.content}</p>
                      </div>
                    </div>
                  );
                })}

                <div className="flex gap-2 items-center">
                  <input
                    type="text"
                    value={commentText[post.id] || ''}
                    onChange={(e) => setCommentText({ ...commentText, [post.id]: e.target.value })}
                    placeholder="Add a comment..."
                    className="flex-1 input-vibe py-2 text-sm"
                    onKeyDown={(e) => e.key === 'Enter' && handleComment(post.id)}
                  />
                  <button 
                    onClick={() => handleComment(post.id)}
                    className="p-2 bg-vibe-purple rounded-xl text-white hover:bg-vibe-purple/80 transition-colors"
                  >
                    <Send size={18} />
                  </button>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
