import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import Scene from '../components/Scene';
import { ChevronRight, Sparkles } from 'lucide-react';

export default function Landing() {
  return (
    <div className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden">
      <Scene />
      
      <div className="relative z-10 text-center px-4 max-w-4xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs font-medium text-vibe-purple mb-6"
        >
          <Sparkles size={14} />
          <span>The University Social Frontier</span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-6xl md:text-8xl font-display font-bold leading-tight mb-6"
        >
          Connect in <br />
          <span className="text-gradient">Pure Motion.</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="text-lg md:text-xl text-gray-400 mb-10 max-w-2xl mx-auto leading-relaxed"
        >
          VIBEs is more than a dating site—it's a vibrant community for students to mingle, 
          share ideas, and find genuine connections through interactive experiences.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <Link to="/auth" className="btn-vibe-primary group flex items-center gap-2 text-lg px-8 py-4">
            Get Started
            <ChevronRight size={20} className="group-hover:translate-x-1 transition-transform" />
          </Link>
          <button className="btn-vibe-secondary text-lg px-8 py-4">
            Explore Forum
          </button>
        </motion.div>
      </div>

      <div className="absolute bottom-10 left-0 right-0 z-10 flex justify-center">
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          className="text-gray-500 text-sm font-medium"
        >
          Scroll to discover
        </motion.div>
      </div>
    </div>
  );
}
