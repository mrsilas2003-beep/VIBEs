import { useStore } from '../store';
import { motion } from 'motion/react';
import { Heart, MessageCircle, Share2, Plus, Sparkles, TrendingUp } from 'lucide-react';
import { Link } from 'react-router-dom';
import { formatDistanceToNow } from 'date-fns';

export default function Dashboard() {
  const { posts, users, currentUser, likePost } = useStore();

  const getAuthor = (id: string) => users.find(u => u.id === id);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
      {/* Left Sidebar - Stats & Suggested */}
      <div className="lg:col-span-3 space-y-6">
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="glass p-6 rounded-3xl"
        >
          <div className="flex items-center gap-4 mb-6">
            <img src={currentUser?.avatar} alt="Avatar" className="w-12 h-12 rounded-full" />
            <div>
              <h3 className="font-bold">{currentUser?.username}</h3>
              <p className="text-xs text-gray-400">{currentUser?.university}</p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white/5 p-3 rounded-2xl text-center">
              <p className="text-lg font-bold">{currentUser?.friends.length}</p>
              <p className="text-[10px] text-gray-500 uppercase tracking-widest">Friends</p>
            </div>
            <div className="bg-white/5 p-3 rounded-2xl text-center">
              <p className="text-lg font-bold">{posts.filter(p => p.authorId === currentUser?.id).length}</p>
              <p className="text-[10px] text-gray-500 uppercase tracking-widest">Posts</p>
            </div>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1 }}
          className="glass p-6 rounded-3xl hidden lg:block"
        >
          <h3 className="font-semibold mb-4 flex items-center gap-2">
            <TrendingUp size={18} className="text-vibe-cyan" />
            Recommended
          </h3>
          <div className="space-y-4">
            {users
              .filter(u => u.id !== currentUser?.id && !currentUser?.friends.includes(u.id))
              .slice(0, 3)
              .map(user => (
                <Link key={user.id} to={`/profile/${user.id}`} className="flex items-center gap-3 hover:bg-white/5 p-2 rounded-xl transition-colors">
                  <img src={user.avatar} alt={user.username} className="w-8 h-8 rounded-full" />
                  <div>
                    <p className="text-xs font-semibold">{user.username}</p>
                    <p className="text-[10px] text-gray-500">{user.university}</p>
                  </div>
                </Link>
              ))}
          </div>
        </motion.div>
      </div>

      {/* Main Feed */}
      <div className="lg:col-span-6 space-y-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass p-4 rounded-3xl"
        >
          <Link to="/forum" className="flex items-center gap-4 bg-white/5 p-4 rounded-2xl hover:bg-white/10 transition-colors">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-vibe-purple to-vibe-pink flex items-center justify-center text-white">
              <Plus size={20} />
            </div>
            <span className="text-gray-400">What's happening at {currentUser?.university}?</span>
          </Link>
        </motion.div>

        <div className="space-y-6">
          {posts.map((post, index) => {
            const author = getAuthor(post.authorId);
            return (
              <motion.div
                key={post.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="glass p-6 rounded-3xl"
              >
                <div className="flex items-center justify-between mb-4">
                  <Link to={`/profile/${author?.id}`} className="flex items-center gap-3">
                    <img src={author?.avatar} alt={author?.username} className="w-10 h-10 rounded-full" />
                    <div>
                      <h4 className="font-semibold">{author?.username}</h4>
                      <p className="text-[10px] text-gray-500">{formatDistanceToNow(new Date(post.timestamp))} ago • {post.category}</p>
                    </div>
                  </Link>
                  <span className="px-3 py-1 rounded-full bg-vibe-purple/10 text-vibe-purple text-[10px] font-bold uppercase tracking-wider">
                    {post.category}
                  </span>
                </div>
                <h3 className="text-xl font-display font-bold mb-3">{post.title}</h3>
                <p className="text-gray-400 mb-6 leading-relaxed">{post.content}</p>
                <div className="flex items-center gap-6 pt-4 border-t border-white/5">
                  <button 
                    onClick={() => likePost(post.id)}
                    className={`flex items-center gap-2 text-sm transition-colors ${post.likes.includes(currentUser?.id || '') ? 'text-vibe-pink' : 'text-gray-500 hover:text-white'}`}
                  >
                    <Heart size={18} fill={post.likes.includes(currentUser?.id || '') ? 'currentColor' : 'none'} />
                    {post.likes.length}
                  </button>
                  <Link to="/forum" className="flex items-center gap-2 text-sm text-gray-500 hover:text-white transition-colors">
                    <MessageCircle size={18} />
                    {post.comments.length}
                  </Link>
                  <button className="flex items-center gap-2 text-sm text-gray-500 hover:text-white transition-colors ml-auto">
                    <Share2 size={18} />
                  </button>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Right Sidebar - Active Threads / Vibes */}
      <div className="lg:col-span-3 space-y-6">
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="glass p-6 rounded-3xl"
        >
          <h3 className="font-semibold mb-4 flex items-center gap-2">
            <Sparkles size={18} className="text-vibe-pink" />
            Active Conversations
          </h3>
          <div className="space-y-4">
            {posts.slice(0, 2).map(p => (
              <div key={p.id} className="border-l-2 border-vibe-purple/30 pl-4 py-1">
                <p className="text-xs font-medium truncate">{p.title}</p>
                <p className="text-[10px] text-gray-500">{p.comments.length} participants</p>
              </div>
            ))}
          </div>
        </motion.div>
        
        <div className="glass p-6 rounded-3xl bg-gradient-to-br from-vibe-purple/20 to-transparent">
          <h4 className="text-sm font-bold mb-2 italic">VIBE Tip</h4>
          <p className="text-xs text-gray-400">Be yourself! Authenticity is the best vibe for finding meaningful connections.</p>
        </div>
      </div>
    </div>
  );
}
