export interface User {
  id: string;
  username: string;
  email: string;
  bio?: string;
  avatar?: string;
  university?: string;
  friends: string[]; // user ids
  friendRequests: string[]; // user ids
}

export interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  content: string;
  timestamp: Date;
  viewOnce: boolean;
  viewed: boolean;
}

export interface ForumPost {
  id: string;
  authorId: string;
  title: string;
  content: string;
  category: "General" | "Dating" | "Events" | "Study" | "Gossip";
  timestamp: Date;
  likes: string[]; // user ids
  comments: ForumComment[];
}

export interface ForumComment {
  id: string;
  authorId: string;
  content: string;
  timestamp: Date;
}

export interface Notification {
  id: string;
  userId: string;
  type: "friend_request" | "friend_accept" | "message" | "forum_like" | "forum_comment";
  fromUserId: string;
  message: string;
  timestamp: Date;
  read: boolean;
}
