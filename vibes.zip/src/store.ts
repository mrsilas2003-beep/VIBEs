import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { User, Message, ForumPost, Notification, ForumComment } from './types';

interface VibeState {
  currentUser: User | null;
  users: User[];
  messages: Message[];
  posts: ForumPost[];
  notifications: Notification[];
  
  // Auth actions
  login: (email: string) => void;
  signup: (username: string, email: string, university: string) => void;
  logout: () => void;
  updateProfile: (data: Partial<User>) => void;
  
  // Social actions
  sendFriendRequest: (toUserId: string) => void;
  acceptFriendRequest: (fromUserId: string) => void;
  
  // Chat actions
  sendMessage: (toUserId: string, content: string, viewOnce: boolean) => void;
  markMessageViewed: (messageId: string) => void;
  
  // Forum actions
  createPost: (title: string, content: string, category: ForumPost['category']) => void;
  likePost: (postId: string) => void;
  addComment: (postId: string, content: string) => void;
  
  // Utils
  markNotificationRead: (id: string) => void;
}

export const useStore = create<VibeState>()(
  persist(
    (set, get) => ({
      currentUser: null,
      users: [
        { id: '1', username: 'Alex', email: 'alex@uni.edu', university: 'Stanford', friends: [], friendRequests: [], bio: 'Love hiking and coding!', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Alex' },
        { id: '2', username: 'Sam', email: 'sam@uni.edu', university: 'MIT', friends: [], friendRequests: [], bio: 'Physics major, coffee addict.', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sam' },
        { id: '3', username: 'Jordan', email: 'jordan@uni.edu', university: 'Harvard', friends: [], friendRequests: [], bio: 'Art history and chill.', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Jordan' },
      ],
      messages: [],
      posts: [
        {
          id: 'p1',
          authorId: '1',
          title: 'Anyone going to the spring gala?',
          content: 'Thinking about wearing something neon. Is that weird for university gala?',
          category: 'Events',
          timestamp: new Date(Date.now() - 3600000 * 24),
          likes: ['2'],
          comments: [
            { id: 'c1', authorId: '2', content: 'Neons are back baby!', timestamp: new Date(Date.now() - 3600000 * 20) }
          ]
        }
      ],
      notifications: [],

      login: (email) => {
        const user = get().users.find(u => u.email === email);
        if (user) set({ currentUser: user });
      },

      signup: (username, email, university) => {
        const newUser: User = {
          id: Math.random().toString(36).substr(2, 9),
          username,
          email,
          university,
          friends: [],
          friendRequests: [],
          avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${username}`
        };
        set(state => ({
          users: [...state.users, newUser],
          currentUser: newUser
        }));
      },

      logout: () => set({ currentUser: null }),

      updateProfile: (data) => set(state => ({
        currentUser: state.currentUser ? { ...state.currentUser, ...data } : null,
        users: state.users.map(u => u.id === state.currentUser?.id ? { ...u, ...data } : u)
      })),

      sendFriendRequest: (toUserId) => {
        const currentUser = get().currentUser;
        if (!currentUser) return;
        
        set(state => ({
          users: state.users.map(u => 
            u.id === toUserId && !u.friendRequests.includes(currentUser.id)
              ? { ...u, friendRequests: [...u.friendRequests, currentUser.id] }
              : u
          ),
          notifications: [
            ...state.notifications,
            {
              id: Math.random().toString(36).substr(2, 9),
              userId: toUserId,
              type: 'friend_request',
              fromUserId: currentUser.id,
              message: `${currentUser.username} sent you a friend request.`,
              timestamp: new Date(),
              read: false
            }
          ]
        }));
      },

      acceptFriendRequest: (fromUserId) => {
        const currentUser = get().currentUser;
        if (!currentUser) return;

        set(state => ({
          currentUser: {
            ...currentUser,
            friends: [...currentUser.friends, fromUserId],
            friendRequests: currentUser.friendRequests.filter(id => id !== fromUserId)
          },
          users: state.users.map(u => {
            if (u.id === currentUser.id) {
              return {
                ...u,
                friends: [...u.friends, fromUserId],
                friendRequests: u.friendRequests.filter(id => id !== fromUserId)
              };
            }
            if (u.id === fromUserId) {
              return { ...u, friends: [...u.friends, currentUser.id] };
            }
            return u;
          }),
          notifications: [
            ...state.notifications,
            {
              id: Math.random().toString(36).substr(2, 9),
              userId: fromUserId,
              type: 'friend_accept',
              fromUserId: currentUser.id,
              message: `${currentUser.username} accepted your friend request.`,
              timestamp: new Date(),
              read: false
            }
          ]
        }));
      },

      sendMessage: (toUserId, content, viewOnce) => {
        const currentUser = get().currentUser;
        if (!currentUser) return;

        const newMessage: Message = {
          id: Math.random().toString(36).substr(2, 9),
          senderId: currentUser.id,
          receiverId: toUserId,
          content,
          timestamp: new Date(),
          viewOnce,
          viewed: false
        };

        set(state => ({
          messages: [...state.messages, newMessage],
          notifications: [
            ...state.notifications,
            {
              id: Math.random().toString(36).substr(2, 9),
              userId: toUserId,
              type: 'message',
              fromUserId: currentUser.id,
              message: `New message from ${currentUser.username}`,
              timestamp: new Date(),
              read: false
            }
          ]
        }));
      },

      markMessageViewed: (messageId) => set(state => ({
        messages: state.messages.map(m => m.id === messageId ? { ...m, viewed: true } : m)
      })),

      createPost: (title, content, category) => {
        const currentUser = get().currentUser;
        if (!currentUser) return;

        const newPost: ForumPost = {
          id: Math.random().toString(36).substr(2, 9),
          authorId: currentUser.id,
          title,
          content,
          category,
          timestamp: new Date(),
          likes: [],
          comments: []
        };

        set(state => ({
          posts: [newPost, ...state.posts]
        }));
      },

      likePost: (postId) => {
        const currentUser = get().currentUser;
        if (!currentUser) return;

        set(state => ({
          posts: state.posts.map(p => {
            if (p.id === postId) {
              const alreadyLiked = p.likes.includes(currentUser.id);
              return {
                ...p,
                likes: alreadyLiked ? p.likes.filter(id => id !== currentUser.id) : [...p.likes, currentUser.id]
              };
            }
            return p;
          })
        }));
      },

      addComment: (postId, content) => {
        const currentUser = get().currentUser;
        if (!currentUser) return;

        const newComment: ForumComment = {
          id: Math.random().toString(36).substr(2, 9),
          authorId: currentUser.id,
          content,
          timestamp: new Date()
        };

        set(state => ({
          posts: state.posts.map(p => p.id === postId ? { ...p, comments: [...p.comments, newComment] } : p)
        }));
      },

      markNotificationRead: (id) => set(state => ({
        notifications: state.notifications.map(n => n.id === id ? { ...n, read: true } : n)
      }))
    }),
    {
      name: 'vibes-storage',
    }
  )
);
