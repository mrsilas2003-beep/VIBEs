/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useStore } from './store';
import Navbar from './components/Navbar';
import Landing from './pages/Landing';
import Auth from './pages/Auth';
import Dashboard from './pages/Dashboard';
import Forum from './pages/Forum';
import Chat from './pages/Chat';
import Profile from './pages/Profile';
import Friends from './pages/Friends';
import { motion, AnimatePresence } from 'motion/react';

function PrivateRoute({ children }: { children: React.ReactNode }) {
  const currentUser = useStore(state => state.currentUser);
  return currentUser ? <>{children}</> : <Navigate to="/auth" />;
}

export default function App() {
  const currentUser = useStore(state => state.currentUser);

  return (
    <Router>
      <div className="min-h-screen relative overflow-x-hidden">
        {currentUser && <Navbar />}
        <main className={currentUser ? "pt-20 pb-10 px-4 md:px-8 max-w-7xl mx-auto" : ""}>
          <AnimatePresence mode="wait">
            <Routes>
              <Route path="/" element={currentUser ? <Navigate to="/dashboard" /> : <Landing />} />
              <Route path="/auth" element={currentUser ? <Navigate to="/dashboard" /> : <Auth />} />
              <Route 
                path="/dashboard" 
                element={
                  <PrivateRoute>
                    <Dashboard />
                  </PrivateRoute>
                } 
              />
              <Route 
                path="/forum" 
                element={
                  <PrivateRoute>
                    <Forum />
                  </PrivateRoute>
                } 
              />
              <Route 
                path="/chat" 
                element={
                  <PrivateRoute>
                    <Chat />
                  </PrivateRoute>
                } 
              />
              <Route 
                path="/profile/:userId" 
                element={
                  <PrivateRoute>
                    <Profile />
                  </PrivateRoute>
                } 
              />
              <Route 
                path="/friends" 
                element={
                  <PrivateRoute>
                    <Friends />
                  </PrivateRoute>
                } 
              />
            </Routes>
          </AnimatePresence>
        </main>
      </div>
    </Router>
  );
}
