import { Link, useLocation } from 'react-router-dom';
import { useStore } from '../store';
import { Home, MessageSquare, Users, User, Bell, LogOut, Search } from 'lucide-react';
import { motion } from 'motion/react';
import { useState } from 'react';

export default function Navbar() {
  const { currentUser, logout, notifications, markNotificationRead } = useStore();
  const location = useLocation();
  const [showNotifications, setShowNotifications] = useState(false);

  const unreadCount = notifications.filter(n => n.userId === currentUser?.id && !n.read).length;

  const navItems = [
    { name: 'Home', path: '/dashboard', icon: Home },
    { name: 'Forum', path: '/forum', icon: MessageSquare },
    { name: 'Friends', path: '/friends', icon: Users },
    { name: 'Messages', path: '/chat', icon: MessageSquare },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass border-b border-white/5">
      <div className="max-w-7xl mx-auto px-4 md:px-8 h-16 flex items-center justify-between">
        <Link to="/" className="text-2xl font-display font-bold text-gradient">
          VIBEs
        </Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center space-x-1">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            const Icon = item.icon;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`relative px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                  isActive ? 'text-white' : 'text-gray-400 hover:text-white'
                }`}
              >
                {isActive && (
                  <motion.div
                    layoutId="navbar-active"
                    className="absolute inset-0 bg-white/10 rounded-full"
                    transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                  />
                )}
                <span className="relative z-10 flex items-center gap-2">
                  <Icon size={18} />
                  {item.name}
                </span>
              </Link>
            );
          })}
        </div>

        <div className="flex items-center space-x-4">
          <div className="relative">
            <button 
              onClick={() => setShowNotifications(!showNotifications)}
              className="relative p-2 text-gray-400 hover:text-white transition-colors"
            >
              <Bell size={20} />
              {unreadCount > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-vibe-pink rounded-full text-[10px] flex items-center justify-center text-white ring-2 ring-black">
                  {unreadCount}
                </span>
              )}
            </button>
            
            {showNotifications && (
              <div className="absolute right-0 mt-2 w-80 glass-dark rounded-2xl shadow-2xl p-4 max-h-[400px] overflow-y-auto">
                <h3 className="text-sm font-semibold mb-4">Notifications</h3>
                <div className="space-y-3">
                  {notifications
                    .filter(n => n.userId === currentUser?.id)
                    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
                    .map(n => (
                      <div 
                        key={n.id} 
                        className={`p-3 rounded-xl transition-colors ${n.read ? 'opacity-50' : 'bg-white/5'}`}
                        onClick={() => markNotificationRead(n.id)}
                      >
                        <p className="text-xs text-gray-300">{n.message}</p>
                        <span className="text-[10px] text-gray-500 mt-1 block">
                          {new Date(n.timestamp).toLocaleTimeString()}
                        </span>
                      </div>
                    ))}
                  {notifications.filter(n => n.userId === currentUser?.id).length === 0 && (
                    <p className="text-center text-gray-500 text-xs py-4">No notifications yet</p>
                  )}
                </div>
              </div>
            )}
          </div>

          <Link to={`/profile/${currentUser?.id}`} className="hover:opacity-80 transition-opacity">
            <img 
              src={currentUser?.avatar} 
              alt="Avatar" 
              className="w-8 h-8 rounded-full ring-2 ring-vibe-purple/30"
            />
          </Link>

          <button 
            onClick={logout}
            className="p-2 text-gray-400 hover:text-vibe-pink transition-colors"
            title="Logout"
          >
            <LogOut size={20} />
          </button>
        </div>
      </div>
    </nav>
  );
}
