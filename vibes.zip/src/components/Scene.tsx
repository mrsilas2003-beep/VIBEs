import { useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Float, MeshDistortMaterial, Sphere, OrbitControls, Environment } from '@react-three/drei';
import * as THREE from 'three';

function InnerScene() {
  const sphereRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (sphereRef.current) {
      sphereRef.current.rotation.x = state.clock.getElapsedTime() * 0.2;
      sphereRef.current.rotation.y = state.clock.getElapsedTime() * 0.3;
    }
  });

  return (
    <>
      <ambientLight intensity={0.5} />
      <pointLight position={[10, 10, 10]} intensity={1} color="#8B5CF6" />
      <pointLight position={[-10, -10, -10]} intensity={1} color="#EC4899" />
      
      <Float speed={2} rotationIntensity={1} floatIntensity={2}>
        <Sphere ref={sphereRef} args={[1, 64, 64]}>
          <MeshDistortMaterial
            color="#8B5CF6"
            speed={3}
            distort={0.4}
            radius={1}
            emissive="#EC4899"
            emissiveIntensity={0.2}
            roughness={0.2}
            metalness={0.8}
          />
        </Sphere>
      </Float>

      <Environment preset="night" />
      <OrbitControls enableZoom={false} enablePan={false} />
    </>
  );
}

export default function Scene() {
  return (
    <div className="absolute inset-0 z-0 opacity-60">
      <Canvas camera={{ position: [0, 0, 5], fov: 45 }}>
        <InnerScene />
      </Canvas>
    </div>
  );
}
